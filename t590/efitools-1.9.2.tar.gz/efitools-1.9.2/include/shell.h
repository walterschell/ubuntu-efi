EFI_STATUS
argsplit(EFI_HANDLE image, int *argc, CHAR16*** ARGV);
