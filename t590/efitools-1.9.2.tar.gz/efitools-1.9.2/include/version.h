#define VERSION "1.9.2"

static void
version(const char *progname)
{
	printf("%s " VERSION "\n", progname);
}

